Updates log

###### 17 April 2021 - 17042021

started the writing the pie menus in python using pyside and qt, the "piemenu_rewrite successful_v0.1.py.bkp" is versioned 0.1, from next time it will be versioned more sense fully starting from 1.

###### 18 April 2021 - 18042021

loaded the json settings into the app and binded hotkeys, tested it, working fine as of now. Got the root exe file name of the active window or app, but as of now I have not used it for any purpose.

Added the class ActiveWindow which takes control of almost everything. **NOTE** this class should only be instanced once.

