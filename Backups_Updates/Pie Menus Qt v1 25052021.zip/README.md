# Pie_Menus for windows



###### Full Detailed Description coming soon, although if you know what pie menus are, you don't need description. 

Blender like pie menus for windows, its not limited or confined to app, you can set up pie menu for any app or window on your system.

###### More features coming soon, if you have any feature request put it in Issues as of now.

Any contributions are most welcome.

Screenshots:

![screen 1](C:\Users\S\Desktop\Project Pie Menus Qt\media\screen 1.png)

![screen 2](C:\Users\S\Desktop\Project Pie Menus Qt\media\screen 2.png)

![image-20210525193951379](C:\Users\S\Desktop\Project Pie Menus Qt\media\screen 3.png)

##### How to run from source code

- Clone the repo or download as zip.
- install python v3 or above and PySide2 from pip.
- run "main.py" directly or from any code editor
- to exit app, exit from hidden icon in tray