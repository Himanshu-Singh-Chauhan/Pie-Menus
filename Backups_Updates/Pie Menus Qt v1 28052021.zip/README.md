# Pie_Menus for windows



###### Full Detailed Description coming soon, although if you know what pie menus are, you don't need description. 

Blender like pie menus for windows, its not limited or confined to app, you can set up pie menu for any app or window on your system.

###### More features coming soon, if you have any feature request put it in Issues as of now.

Any contributions are most welcome.

Screenshots:

<a href="https://ibb.co/fMXngsr"><img src="https://i.ibb.co/31TM3nS/screen-1.png" alt="screen-1" border="0"></a>



<a href="https://ibb.co/QbcyWtF"><img src="https://i.ibb.co/cgv4WVc/screen-2.png" alt="screen-2" border="0"></a>

##### How to run from source code

- Clone the repo or download as zip.
- install python v3 or above and PySide2 from pip.
- run "main.py" directly or from any code editor
- to exit app, exit from hidden icon in tray