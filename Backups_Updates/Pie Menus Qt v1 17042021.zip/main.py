from PySide2 import QtGui, QtWidgets, QtCore
from PyQt5.QtCore import Qt
from PySide2.QtCore import *
from PySide2.QtGui import *
from PySide2.QtWidgets import *
import sys
import os

# Global varibals:
debugMode = False

class Window():
    pass

def main():
    app = QtWidgets.QApplication()
    window = Window()
    sys.exit(app.exec_())

if __name__ == "__main__":
    main() 