To dos

- [ ] Load settings file into python
- [ ] refactor **little bit** the settings json

