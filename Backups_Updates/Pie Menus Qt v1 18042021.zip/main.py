import os
import json
from win32gui import GetWindowText, GetForegroundWindow, GetClassName
from win32process import GetWindowThreadProcessId
import psutil
from piemenu_backend import *

class ActiveProfile:
    def __init__(self) -> None:
        self.activeWindow = None
        self.profile = None
        self.loadedHotkeys = []
        self.A_ThisHotkey = None
        self.loadGlobal()
        self.timerCheckHotkey = QTimer()
        self.timerCheckHotkey.timeout.connect(self.isHotkeyEvent)
        self.timerCheckHotkey.start(25)


    def changeDetected(self, activeWindow):
        global regApps

        if activeWindow not in regApps:
            self.loadGlobal()
            return
            
        self.activeWindow = activeWindow
        self.loadProfile()
        self.loadHotkeys()

    def loadHotkeys(self):
        self.flushHotkeys()
        for menus in self.profile["pieMenus"]:
            # keyboard.add_hotkey(menus["hotkey"], doNothing, suppress=True)
            keyboard.add_hotkey(menus["hotkey"], self.registerHotkeyEvent, suppress=True)
            self.loadedHotkeys.append(menus["hotkey"])
        
    def flushHotkeys(self):
        if len(self.loadedHotkeys):
            keyboard.unhook_all_hotkeys()
        
        self.loadedHotkeys.clear()

    def loadProfile(self):
        global settings
        for profile in settings["appProfiles"]:
            if profile["ahkHandle"] == self.activeWindow:
                self.profile = profile
                break

    def loadGlobal(self):
        global settings

        self.activeWindow = None
        for profile in settings["appProfiles"]:
            if profile["ahkHandle"] == "ahk_group regApps":
                self.profile = profile
                break
        self.loadHotkeys()

    def registerHotkeyEvent(self):
        for hotkey in self.loadedHotkeys:
            if keyboard.is_pressed(hotkey):
                self.A_ThisHotkey = hotkey
                break

    def isHotkeyEvent(self):
        if self.A_ThisHotkey == None:
            return
        self.hotkeyEvent()

        
    def hotkeyEvent(self):
        print(f"hotkey pressed : {self.A_ThisHotkey}")
        window.showMenu(8)
        self.A_ThisHotkey = None

# Global varibals:
debugMode = False
flag = False
hold = False

# ----Obselete method---------
# def doNothing():
#     # this just does nothing, is used when to detect hotkey and do nothing
#     pass


def detectWindowChange():
    global activeProfile
    global settings

    previousActiveWindow = activeProfile.activeWindow
    try:
        activeTittle = GetWindowText(GetForegroundWindow())
        pid = GetWindowThreadProcessId(GetForegroundWindow())
        rootExe = psutil.Process(pid[-1]).name()
    except:
        return

    activeWindow = GetClassName(GetForegroundWindow())
    print(previousActiveWindow)
    if previousActiveWindow == activeWindow:
        print("yo")
        return
    else:
        activeProfile.changeDetected(activeWindow)
    


# Json settings loading
script_dir = os.path.dirname(__file__)
try:
    settings = open(os.path.join(script_dir, "settings/appProfiles.json"))
    settings = json.load(settings)
except:
    print("could not locate or load the json settings - appProfiles")

try:
    globalSettings = open(os.path.join(script_dir, "settings/globalSettings.json"))
    globalSettings = json.load(globalSettings)
except:
    print("could not locate or load the json globalSettings - globalSettings")


# ------------------------------------ MAIN ---------------------------------
app = QtWidgets.QApplication()
window = Window()

# *****IMPORTANT********: # get the mouse pos here by itself to increase accuracy of opening position.

# Registering the app profiles 
regApps = []
for profiles in settings["appProfiles"]:
    if profiles["ahkHandle"] == "ahk_group regApps":
        continue
    # do not register profile if not enabled
    if profiles["enable"] == 0:
        continue
    regApps.append(profiles["ahkHandle"])


activeProfile = ActiveProfile()


# Timers
timerWinChange = QTimer()
timerWinChange.timeout.connect(detectWindowChange)

# Timer starts
timerWinChange.start(25)


# ----------------------END-----------------------------
# This statement has to stay the last line
# - everything below will go out of scope of any thing.
sys.exit(app.exec_())
# ----------------------/END-----------------------------