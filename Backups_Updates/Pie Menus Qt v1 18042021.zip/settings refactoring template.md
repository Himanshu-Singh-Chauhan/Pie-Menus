{

"appProfiles": [{"name", "ahkHandle", "enable", "pieMenus"=[{}]}]

}