To dos

- [x] Load settings file into python
- [x] refactor **little bit** the settings json
- [x] get the root exe of the active window or app
- [x] instead of lettings new Qtimers get created everytime, just stop and start them, it will save time and CPU
- [x] add frosty glass behind pie menus, and lock mouse to that region to receive mouse clicks and keyboard events. (Instead of doing this, I implemented own mouse hook, so now this is not required)
- [x] Multi Monitor support 
- [ ] Android like toast messege, on errors, exceptions, volume up and down, bg tasks, way to use and limitations of pie menus.
- [ ] detect window changes by capturing system messages on window change.
- [ ] Add capslock key remaping just like that ahk script.
- [ ] improve window change detection function, maybe its working extra stuff not required.
- [ ] Get new moniters plugged in and stuff, and DPI change per monitor
