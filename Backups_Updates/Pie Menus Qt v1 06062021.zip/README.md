# Pie_Menus for windows



###### Full Detailed Description coming soon, although if you know what pie menus are, you don't need description. 

Blender like pie menus for windows, its not limited or confined to app, you can set up pie menu for any app or window on your system.



Quick **Getting Started** : After install and running, press tilde key  `  on keyboard to call pie menus, then use mouse to select menu, you can also hold the tilde key, and then just hover on the menu you want to activate and then let go the tilde key. Pressing 'e' in a notepad opens up another pie menus, which is assigned to notepad and will only open in notepad. As of now only these pie menus are available, but you add more yourself by editing appProfiles.json file. More stock menus will be added soon. you exit from tray icon.



###### More features coming soon, if you have any feature request put it in Issues as of now.

Any contributions are most welcome.

Screenshots:

<a><img src="https://github.com/Himanshu-Singh-Chauhan/Pie-Menus/blob/main/resources/pie_screenshots/screen%201.png" alt="Pie Menus screen shots" style="border-radius:20px"></a>



<a><img src="https://github.com/Himanshu-Singh-Chauhan/Pie-Menus/blob/main/resources/pie_screenshots/screen%203.png" alt="Pie Menus screen shots" style="border-radius:20px"></a>

##### How to run from source code

- Clone the repo or download as zip.
- install python v3 or above and PySide2 from pip.
- run "main.py" directly or from any code editor
- to exit app, exit from hidden icon in tray

<br><br>

## want to *Support* the project ##
<p align = "left"><a href = "https://www.buymeacoffee.com/HimanshuChauhan"><img src="https://github.com/Himanshu-Singh-Chauhan/Pie-Menus/blob/main/resources/buymeacoffee.png" alt="Donation Link to Buy Me a Coffee"></a></p>