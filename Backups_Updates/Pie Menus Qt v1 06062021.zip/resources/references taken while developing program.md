https://stackoverflow.com/questions/31379169/setting-up-a-windowshook-in-python-ctypes-windows-api

https://docs.microsoft.com/en-us/windows/win32/winmsg/using-hooks?redirectedfrom=MSDN

https://www.geeksforgeeks.org/handling-a-threads-exception-in-the-caller-thread-in-python/

[PYTHON - Ctypes : OSError: exception: access violation writing 0xFFFFFFFFFA1C001B - Stack Overflow](https://stackoverflow.com/questions/48788549/python-ctypes-oserror-exception-access-violation-writing-0xfffffffffa1c001)

[python windows mouse hook crash - Stack Overflow](https://stackoverflow.com/questions/38557655/python-windows-mouse-hook-crash)

[Low-level Windows API hooks from C# to stop unwanted keystrokes - CodeProject](https://www.codeproject.com/Articles/14485/Low-level-Windows-API-hooks-from-C-to-stop-unwante)

[python - "inconsistent use of tabs and spaces in indentation" - Stack Overflow](https://stackoverflow.com/questions/5685406/inconsistent-use-of-tabs-and-spaces-in-indentation)

[CallNextHookEx function (winuser.h) - Win32 apps | Microsoft Docs](https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-callnexthookex)

[ctypes.windll.user32.CallNextHookEx Example (programtalk.com)](https://programtalk.com/python-examples/ctypes.windll.user32.CallNextHookEx/)

[Python hook proc (programcreek.com)](https://www.programcreek.com/python/?CodeExample=hook+proc)

[SetWindowsHookExA function (winuser.h) - Win32 apps | Microsoft Docs](https://docs.microsoft.com/en-us/windows/win32/api/winuser/nf-winuser-setwindowshookexa)

[Python using WinAPI SetWindowsHookExA on windows 10 - Stack Overflow](https://stackoverflow.com/questions/53732628/python-using-winapi-setwindowshookexa-on-windows-10)

[windows - Python simulate keydown - Stack Overflow](https://stackoverflow.com/questions/11906925/python-simulate-keydown/11910555#11910555)

[This is a pure python (or as close as possible) keyboard hook module. · GitHub](https://gist.github.com/ethanhs/80f0a7cc5c7881f5921f)

[python - Can't load pywin32 library win32gui - Stack Overflow](https://stackoverflow.com/questions/3956178/cant-load-pywin32-library-win32gui)