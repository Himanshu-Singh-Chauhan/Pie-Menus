To dos

- [x] Load settings file into python
- [x] refactor **little bit** the settings json
- [ ] get the root exe of the active window or app
- [ ] improve window change detection function, maybe its working extra stuff not required.
- [ ] instead of lettings new Qtimers get created everytime, just stop and start them, it will save time and CPU
- [ ] Get new moniters plugged in and stuff, and DPI change per monitor
- [ ] add frosty glass behind pie menus, and lock mouse to that region to receive mouse clicks and keyboard events.
- [ ] detect window changes by capturing system messages on window change.

